# -*- coding: utf-8 -*-

from odoo import models, fields

 

class Singer(models.Model):

    _name = "song.singer"

    name = fields.Char(string="Name", required=True)

    birthday = fields.Date(string="Date of Birth")

    disks = fields.Many2many('song.disk', string="Disks")

 

class Disk(models.Model):

    _name = "song.disk"

    name = fields.Char(string="Title", required=True)

    publish_date = fields.Date(string="Publishing Date")

    singers = fields.Many2many('song.singer', string="Singers")

    songs = fields.One2many('song.song', 'disk_id', string="Songs")

 

class Song(models.Model):

    _name = "song.song"

    name = fields.Char(string="Title", required=True)

    order = fields.Integer(string="Order")

    duration = fields.Integer(string="Duration")

    disk_id = fields.Many2one('song.disk', string="Disk")